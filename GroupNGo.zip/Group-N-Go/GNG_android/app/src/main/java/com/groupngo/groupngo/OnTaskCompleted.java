package com.groupngo.groupngo;

/**
 * Created by mickey on 11/16/14.
 */
public interface OnTaskCompleted {
    void onTaskCompleted();

}
