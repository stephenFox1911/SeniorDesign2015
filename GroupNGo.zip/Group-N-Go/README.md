Group-N-Go
========

Helping students navigate the Georgia Tech campus safely

Stephen Fox
Chris Gordan
Adam Yost
Mickey
