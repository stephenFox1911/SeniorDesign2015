'user strict';
app.controller('HomeCtrl', function($scope){

});